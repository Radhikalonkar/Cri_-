﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cricket_Team_Managment
{
    class playerdetails
    {
        public int jersy_no { get; set; }

        public string player_name { get; set; }
        public string role_player { get; set; }
        public string nationality { get; set; }

        public override string ToString()
        {
            string mydata = "";
            mydata += jersy_no.ToString() + "\n";
            mydata += player_name.ToString() + "\n";
            mydata += role_player.ToString() + "\n";
            mydata += nationality.ToString() + "\n";
            return mydata;
        }



    }
}
