﻿CREATE TABLE [dbo].[cskbatsmen] (
    [jersy_no]         INT        NOT NULL,
    [no_of_matches]    INT        NULL,
    [No_of_runs]       INT        NULL,
    [average]          INT NULL,
    [strike_rate]      INT NULL,
    [No_centuries]     INT        NULL,
    [no_halfcenturies] INT        NULL,
    FOREIGN KEY ([jersy_no]) REFERENCES [dbo].[playerdetails] ([jersy_no])
);

