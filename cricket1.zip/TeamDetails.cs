﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Cricket_Team_Managment
{
    public partial class TeamDetails : Form
    {
        public TeamDetails()
        {
            InitializeComponent();
        }

        private void txtpdetails_Click(object sender, EventArgs e)
        {
            cskplayers t = new cskplayers();
            t.Show();
            this.Hide();
        }

        private void txtadd_Click(object sender, EventArgs e)
        {
            cskadddetails t = new cskadddetails();
            t.Show();
            this.Hide();

        }

        private void txtbowler_Click(object sender, EventArgs e)
        {
            bowlstatics t = new bowlstatics();
            t.Show();
            this.Hide();

            
        }

        private void txtbatsman_Click(object sender, EventArgs e)
        {
            cskbatsman c = new cskbatsman();
            c.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
