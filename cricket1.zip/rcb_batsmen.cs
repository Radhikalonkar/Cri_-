﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cricket_Team_Managment
{
    class rcb_batsmen
    {
        public int jersy_no { get; set; }
        public string player_name { get; set; }

        public int no_of_matches { get; set; }
        public int runs { get; set; }
        public float b_average { get; set; }
        public float strike { get; set; }
        

        public override string ToString()
        {
            string mydata = "";
            mydata += jersy_no.ToString() + "\n";
            mydata += player_name.ToString() + "\n";

            mydata += no_of_matches.ToString() + "\n";
            mydata += runs.ToString() + "\n";
            mydata += b_average.ToString() + "\n";
            mydata += strike.ToString() + "\n";
            

            return mydata;

        }
    }
}
