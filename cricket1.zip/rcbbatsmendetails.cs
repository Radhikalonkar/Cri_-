﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{
    public partial class rcbbatsmendetails : Form
    {
        SqlConnection conn;
        public rcbbatsmendetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            rcbbatsmenaddetails r = new rcbbatsmenaddetails();
            r.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string txt = txtsearch.Text.ToString();
            if (txt == "All Details")

            {
                conn.Open();
                List<rcb_batsmen> b = new List<rcb_batsmen>();
                string sql1 = "Select * from rcb_batsmen";
                SqlCommand cmd1 = new SqlCommand(sql1, conn);
                SqlDataReader reader = cmd1.ExecuteReader();
                while (reader.Read())
                {
                    rcb_batsmen c = new rcb_batsmen();
                    c.jersy_no = int.Parse(reader[0].ToString());
                    c.player_name = reader[1].ToString();

                    c.no_of_matches = int.Parse(reader[2].ToString());
                    c.runs = int.Parse(reader[3].ToString());
                    c.b_average = float.Parse(reader[4].ToString());
                    c.strike = float.Parse(reader[5].ToString());
                    
                    b.Add(c);



                }
                conn.Close();
                txtgrid.DataSource = b;

            }
            else if (txt == "Highest Runs")
            {


                List<rcb_batsmen> b1 = new List<rcb_batsmen>();
                string sql2 = "Select * from rcb_batsmen where no_of_runs=" + "(select max(no_of_runs) from rcb_batsmen)";
                try
                {
                    conn.Open();
                    SqlCommand cmd2 = new SqlCommand(sql2, conn);
                    SqlDataReader reader = cmd2.ExecuteReader();
                    if (reader.Read())
                    {
                        rcb_batsmen c = new rcb_batsmen();
                        c.jersy_no = int.Parse(reader[0].ToString());
                        c.player_name = reader[1].ToString();

                        c.no_of_matches = int.Parse(reader[2].ToString());
                        c.runs = int.Parse(reader[3].ToString());
                        c.b_average = float.Parse(reader[4].ToString());
                        c.strike = float.Parse(reader[5].ToString());

                        b1.Add(c);
                    }



                }
                catch (Exception o)
                {
                    MessageBox.Show(o.Message);
                }
                conn.Close();
                txtgrid.DataSource = b1;
            }
            else if (txt == "Best Average")
            {

                conn.Open();
                List<rcb_batsmen> b2 = new List<rcb_batsmen>();
                string sql3 = "Select * from rcb_batsmen where  batting_average=" + "(Select max(batting_average) from rcb_batsmen where batting_average>0)";
                SqlCommand cmd3 = new SqlCommand(sql3, conn);
                SqlDataReader reader = cmd3.ExecuteReader();
                while (reader.Read())
                {
                    rcb_batsmen c = new rcb_batsmen();
                    c.jersy_no = int.Parse(reader[0].ToString());
                    c.player_name = reader[1].ToString();

                    c.no_of_matches = int.Parse(reader[2].ToString());
                    c.runs = int.Parse(reader[3].ToString());
                    c.b_average = float.Parse(reader[4].ToString());
                    c.strike = float.Parse(reader[5].ToString());

                    b2.Add(c);



                }
                conn.Close();
                txtgrid.DataSource = b2;
            }
            else if (txt == "Best StrikeRate")
            {

                conn.Open();
                List<rcb_batsmen> b3 = new List<rcb_batsmen>();
                string sql4 = "Select * from rcb_batsmen where  strike_rate=" + "(Select max(strike_rate) from rcb_batsmen  )";
                SqlCommand cmd4 = new SqlCommand(sql4, conn);
                SqlDataReader reader = cmd4.ExecuteReader();
                while (reader.Read())
                {
                    rcb_batsmen c = new rcb_batsmen();
                    c.jersy_no = int.Parse(reader[0].ToString());
                    c.player_name = reader[1].ToString();

                    c.no_of_matches = int.Parse(reader[2].ToString());
                    c.runs = int.Parse(reader[3].ToString());
                    c.b_average = float.Parse(reader[4].ToString());
                    c.strike = float.Parse(reader[5].ToString());

                    b3.Add(c);



                }
                txtgrid.Visible = true;
                conn.Close();
                txtgrid.DataSource = b3;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Rcbdetails r = new Rcbdetails();
            r.Show();
            this.Hide();
        }
    }
}
