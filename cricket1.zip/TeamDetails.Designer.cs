﻿namespace Cricket_Team_Managment
{
    partial class TeamDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtpdetails = new System.Windows.Forms.Button();
            this.txtbowler = new System.Windows.Forms.Button();
            this.txtbatsman = new System.Windows.Forms.Button();
            this.txtadd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtpdetails
            // 
            this.txtpdetails.Location = new System.Drawing.Point(299, 60);
            this.txtpdetails.Name = "txtpdetails";
            this.txtpdetails.Size = new System.Drawing.Size(107, 49);
            this.txtpdetails.TabIndex = 0;
            this.txtpdetails.Text = "Players Details";
            this.txtpdetails.UseVisualStyleBackColor = true;
            this.txtpdetails.Click += new System.EventHandler(this.txtpdetails_Click);
            // 
            // txtbowler
            // 
            this.txtbowler.Location = new System.Drawing.Point(299, 178);
            this.txtbowler.Name = "txtbowler";
            this.txtbowler.Size = new System.Drawing.Size(107, 49);
            this.txtbowler.TabIndex = 1;
            this.txtbowler.Text = "Bowler Statics";
            this.txtbowler.UseVisualStyleBackColor = true;
            this.txtbowler.Click += new System.EventHandler(this.txtbowler_Click);
            // 
            // txtbatsman
            // 
            this.txtbatsman.Location = new System.Drawing.Point(299, 284);
            this.txtbatsman.Name = "txtbatsman";
            this.txtbatsman.Size = new System.Drawing.Size(107, 49);
            this.txtbatsman.TabIndex = 2;
            this.txtbatsman.Text = "Batsman Statics";
            this.txtbatsman.UseVisualStyleBackColor = true;
            this.txtbatsman.Click += new System.EventHandler(this.txtbatsman_Click);
            // 
            // txtadd
            // 
            this.txtadd.Location = new System.Drawing.Point(654, 24);
            this.txtadd.Name = "txtadd";
            this.txtadd.Size = new System.Drawing.Size(107, 29);
            this.txtadd.TabIndex = 3;
            this.txtadd.Text = "Add Details";
            this.txtadd.UseVisualStyleBackColor = true;
            this.txtadd.Click += new System.EventHandler(this.txtadd_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(314, 391);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TeamDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtadd);
            this.Controls.Add(this.txtbatsman);
            this.Controls.Add(this.txtbowler);
            this.Controls.Add(this.txtpdetails);
            this.Name = "TeamDetails";
            this.Text = "TeamDetails";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button txtpdetails;
        private System.Windows.Forms.Button txtbowler;
        private System.Windows.Forms.Button txtbatsman;
        private System.Windows.Forms.Button txtadd;
        private System.Windows.Forms.Button button1;
    }
}