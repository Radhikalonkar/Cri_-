﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Cricket_Team_Managment
{
    public partial class rcbaddplayers : Form
    {
        SqlConnection conn;
         
        public rcbaddplayers()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
      

            
            
                int playerno = int.Parse(txtjersey1.Value.ToString());
                string playername = txtname1.Text.ToString();
                string role = txtrole1.Text.ToString();
                string national = txtnationality1.Text.ToString();


                string sql1 = String.Format("insert into rcb_details values('{0}','{1}','{2}','{3}')", playerno, playername, role, national);

                try
                {
                    conn.Open();
                    SqlCommand cmd1 = new SqlCommand(sql1, conn);
                    cmd1.ExecuteNonQuery();
                }

                catch (Exception o)
                {
                    MessageBox.Show(o.Message);
                }
                conn.Close();
                clear();

            }
            private void clear()
            {
                txtjersey1.Value = 0;
                txtname1.Text = "";
                txtrole1.Text = "";
                txtnationality1.Text = "";


            }

        private void rcbaddplayers_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rcbdetails r = new Rcbdetails();
            r.Show();
            this.Hide();
        }
    }
    }

