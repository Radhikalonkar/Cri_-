﻿namespace Cricket_Team_Managment
{
    partial class Rcbdetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtadd = new System.Windows.Forms.Button();
            this.txtbatsman = new System.Windows.Forms.Button();
            this.txtbowler = new System.Windows.Forms.Button();
            this.txtpdetails = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtadd
            // 
            this.txtadd.Location = new System.Drawing.Point(695, 12);
            this.txtadd.Name = "txtadd";
            this.txtadd.Size = new System.Drawing.Size(82, 28);
            this.txtadd.TabIndex = 7;
            this.txtadd.Text = "Add Details";
            this.txtadd.UseVisualStyleBackColor = true;
            this.txtadd.Click += new System.EventHandler(this.txtadd_Click);
            // 
            // txtbatsman
            // 
            this.txtbatsman.Location = new System.Drawing.Point(347, 295);
            this.txtbatsman.Name = "txtbatsman";
            this.txtbatsman.Size = new System.Drawing.Size(107, 49);
            this.txtbatsman.TabIndex = 6;
            this.txtbatsman.Text = "Batsman Statics";
            this.txtbatsman.UseVisualStyleBackColor = true;
            this.txtbatsman.Click += new System.EventHandler(this.txtbatsman_Click);
            // 
            // txtbowler
            // 
            this.txtbowler.Location = new System.Drawing.Point(347, 182);
            this.txtbowler.Name = "txtbowler";
            this.txtbowler.Size = new System.Drawing.Size(107, 49);
            this.txtbowler.TabIndex = 5;
            this.txtbowler.Text = "Bowler Statics";
            this.txtbowler.UseVisualStyleBackColor = true;
            this.txtbowler.Click += new System.EventHandler(this.txtbowler_Click);
            // 
            // txtpdetails
            // 
            this.txtpdetails.Location = new System.Drawing.Point(347, 65);
            this.txtpdetails.Name = "txtpdetails";
            this.txtpdetails.Size = new System.Drawing.Size(107, 49);
            this.txtpdetails.TabIndex = 4;
            this.txtpdetails.Text = "Players Details";
            this.txtpdetails.UseVisualStyleBackColor = true;
            this.txtpdetails.Click += new System.EventHandler(this.txtpdetails_Click);
            // 
            // Rcbdetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtadd);
            this.Controls.Add(this.txtbatsman);
            this.Controls.Add(this.txtbowler);
            this.Controls.Add(this.txtpdetails);
            this.Name = "Rcbdetails";
            this.Text = "Rcbdetails";
            this.Load += new System.EventHandler(this.Rcbdetails_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button txtadd;
        private System.Windows.Forms.Button txtbatsman;
        private System.Windows.Forms.Button txtbowler;
        private System.Windows.Forms.Button txtpdetails;
    }
}