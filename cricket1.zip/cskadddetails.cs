﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{
    public partial class cskadddetails : Form

    {
        SqlConnection conn;
        
        public cskadddetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int playerno = int.Parse(txtjersey.Value.ToString());
            string playername = txtname.Text.ToString();
            string role = txtrole.Text.ToString();
            string national = txtnationality.Text.ToString();
            

            string sql1 = String.Format("insert into playerdetails values('{0}','{1}','{2}','{3}')", playerno, playername, role, national);
 
            try
            {
                conn.Open();
                SqlCommand cmd1 = new SqlCommand(sql1, conn);
                cmd1.ExecuteNonQuery();
                
                
                  

            }

            catch (Exception o)
            {
                MessageBox.Show(o.Message);
            }
            conn.Close();
            clear();
            
        }
        private void clear()
        {
            txtjersey.Value = 0;
            txtname.Text = "";
            txtrole.Text = "";
            txtnationality.Text = "";
            

        }

        private void cskadddetails_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtnationality_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtrole_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtjersey_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            TeamDetails t = new TeamDetails();
            t.Show();
            this.Hide();
        }
    }
}
