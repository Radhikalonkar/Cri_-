﻿create view max_wickets as select jersy_no, no_of_runs from cskbatsmen union select jersy_no,no_of_runs from rcb_batsmen;

select * from max_wickets where no_of_runs=(select MAX(no_of_runs) from max_wickets );
