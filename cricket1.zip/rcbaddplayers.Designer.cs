﻿namespace Cricket_Team_Managment
{
    partial class rcbaddplayers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnationality1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtrole1 = new System.Windows.Forms.TextBox();
            this.txtname1 = new System.Windows.Forms.TextBox();
            this.txtjersey1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.txtjersey1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtnationality1
            // 
            this.txtnationality1.Location = new System.Drawing.Point(331, 169);
            this.txtnationality1.Name = "txtnationality1";
            this.txtnationality1.Size = new System.Drawing.Size(240, 20);
            this.txtnationality1.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(188, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 36;
            this.label4.Text = "Nationality";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(356, 245);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 33);
            this.button1.TabIndex = 35;
            this.button1.Text = "ADD Details";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtrole1
            // 
            this.txtrole1.Location = new System.Drawing.Point(331, 126);
            this.txtrole1.Name = "txtrole1";
            this.txtrole1.Size = new System.Drawing.Size(240, 20);
            this.txtrole1.TabIndex = 34;
            // 
            // txtname1
            // 
            this.txtname1.Location = new System.Drawing.Point(331, 93);
            this.txtname1.Name = "txtname1";
            this.txtname1.Size = new System.Drawing.Size(240, 20);
            this.txtname1.TabIndex = 33;
            // 
            // txtjersey1
            // 
            this.txtjersey1.Location = new System.Drawing.Point(331, 62);
            this.txtjersey1.Name = "txtjersey1";
            this.txtjersey1.Size = new System.Drawing.Size(240, 20);
            this.txtjersey1.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(188, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 31;
            this.label3.Text = "Role";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(188, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 30;
            this.label2.Text = "Player Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(188, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "Jersey No";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(568, 250);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 38;
            this.button2.Text = "back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // rcbaddplayers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtnationality1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtrole1);
            this.Controls.Add(this.txtname1);
            this.Controls.Add(this.txtjersey1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "rcbaddplayers";
            this.Text = "rcbaddplayers";
            this.Load += new System.EventHandler(this.rcbaddplayers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtjersey1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnationality1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtrole1;
        private System.Windows.Forms.TextBox txtname1;
        private System.Windows.Forms.NumericUpDown txtjersey1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
    }
}