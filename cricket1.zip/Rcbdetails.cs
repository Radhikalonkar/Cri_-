﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Managment
{
    public partial class Rcbdetails : Form
    {
        public Rcbdetails()
        {
            InitializeComponent();
        }

        private void txtpdetails_Click(object sender, EventArgs e)
        {
            RCBSHOW s = new RCBSHOW();
            s.Show();
            this.Hide();


        }

        private void txtadd_Click(object sender, EventArgs e)
        {
            rcbaddplayers r = new rcbaddplayers();
            r.Show();
            this.Hide();
        }

        private void Rcbdetails_Load(object sender, EventArgs e)
        {

        }

        private void txtbowler_Click(object sender, EventArgs e)
        {
            rcbbowlers r = new rcbbowlers();
            r.Show();
            this.Hide();

        }

        private void txtbatsman_Click(object sender, EventArgs e)
        {
            rcbbatsmendetails r = new rcbbatsmendetails();
            r.Show();
            this.Hide();
        }
    }
}
