﻿CREATE TABLE [dbo].[rcb_batsmen] (
    [jersy_no]        INT          NOT NULL,
    [player_name]     VARCHAR (50) NULL,
    [no_of_matches]   INT          NULL,
    [no_of_runs]      INT          NULL,
    [batting_average] FLOAT (53)   NULL,
    [strike_rate]     FLOAT (53)   NULL,
    [No_centuries] INT NULL, 
    [No_halfcenturies] INT NULL, 
    FOREIGN KEY ([jersy_no]) REFERENCES [dbo].[rcb_details] ([jersy_no])
);

