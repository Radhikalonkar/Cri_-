﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cricket_Team_Managment
{
    class rcb_bowlers
    {
        public int jersy_no { get; set; }
        public string player_name { get; set; }
        public int no_of_matches { get; set; }
        public int wickets { get; set; }
        public float average { get; set; }
        public float economy { get; set; }

        public override string ToString()
        {
            string mydata = "";
            mydata += jersy_no.ToString() + "\n";
            mydata += player_name.ToString() + "\n";
            mydata += no_of_matches.ToString() + "\n";
            mydata += wickets.ToString() + "\n";
            mydata += average.ToString() + "\n";
            mydata += economy.ToString() + "\n";
            return mydata;

        }
    }
}
