﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{
    public partial class batsmenstats : Form
    {
        SqlConnection conn;
        public batsmenstats()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cskbatsmen b = new cskbatsmen();
            b.jersy_no = int.Parse(txtno.Value.ToString());
            
            b.no_of_matches = int.Parse(txtmatch.Value.ToString());
            b.b_average = float.Parse(txtavg.Text.ToString());
            b.runs = int.Parse(txtwickets.Value.ToString());
            b.strike = float.Parse(txtstrike.Text.ToString());
            b.full= int.Parse(txtcent1.Value.ToString());
            b.half= int.Parse(txthalf.Value.ToString());
            string sql2 = String.Format("insert into cskbatsmen values('{0}','{1}','{2}','{3}','{4}','{5}','{6}')'", b.jersy_no, b.no_of_matches, b.runs, b.b_average, b.strike,b.full,b.half);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql2, conn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception o)
            {
                MessageBox.Show(o.Message);


            }
            conn.Close();
            clear();

        }
        private void clear()
        {
            txtno.Value = 0;
            
            txtmatch.Value = 0;
            txtwickets.Value = 0;
            txtavg.Text = "";
            txtstrike.Text = "";
            txtcent1.Value = 0;
            txthalf.Value = 0;



        }

        private void button2_Click(object sender, EventArgs e)
        {
            cskbatsman b = new cskbatsman();
            b.Show();
            this.Hide();
        }
    }
}
