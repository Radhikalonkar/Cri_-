﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        public Form1()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtcsk_Click(object sender, EventArgs e)
        {
            TeamDetails t = new TeamDetails();
            t.Show();
            this.Hide();
        }

        private void txtrxcb_Click(object sender, EventArgs e)
        {
            Rcbdetails r = new Rcbdetails();
            r.Show();
            this.Hide();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<orangecap> o = new List<orangecap>();
            try
            {

                conn.Open();
                orangecap t = new orangecap();
                string sql = "select * from max_runs";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    t.jersy_no = int.Parse(reader[0].ToString());
                    t.runs = int.Parse(reader[1].ToString());
                    o.Add(t);

                }

            }
            catch(Exception p)
            {
                MessageBox.Show(p.Message);
            }
            conn.Close();
            
        }
    }
}
