﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{

    public partial class cskbatsman : Form
    {
        SqlConnection conn;
       
        public cskbatsman()
           
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);
        }

        private void cskbatsman_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            batsmenstats b = new batsmenstats();
            b.Show();
            this.Hide();
            txtgrid.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtgrid.Visible = false;

            string txt = txtsearch.Text.ToString();
            if (txt == "All Details")

            {
                conn.Open();
                List<cskbatsmen> b = new List<cskbatsmen>();
                string sql1 = "Select * from cskbatsmen";
                SqlCommand cmd1 = new SqlCommand(sql1, conn);
                SqlDataReader reader = cmd1.ExecuteReader();
                while (reader.Read())
                {
                    cskbatsmen c = new cskbatsmen();
                    c.jersy_no = int.Parse(reader[0].ToString());

                    c.no_of_matches = int.Parse(reader[1].ToString());
                    c.runs = int.Parse(reader[2].ToString());
                    c.b_average = float.Parse(reader[3].ToString());
                    c.strike = float.Parse(reader[4].ToString());
                    c.full = int.Parse(reader[5].ToString());
                    c.half = int.Parse(reader[6].ToString());
                    b.Add(c);



                }
                conn.Close();
                txtgrid.DataSource = b;

            }
            else if (txt == "Highest Runs")
            {


                List<cskbatsmen> b1 = new List<cskbatsmen>();
                string sql2 = "Select * from cskbatsmen where no_of_runs=" + "(select max(no_of_runs) from cskbatsmen)";
                try
                {
                    conn.Open();
                    SqlCommand cmd2 = new SqlCommand(sql2, conn);
                    SqlDataReader reader = cmd2.ExecuteReader();
                    if (reader.Read())
                    {
                        cskbatsmen c = new cskbatsmen();
                        c.jersy_no = int.Parse(reader[0].ToString());

                        c.no_of_matches = int.Parse(reader[1].ToString());
                        c.runs = int.Parse(reader[2].ToString());
                        c.b_average = float.Parse(reader[3].ToString());
                        c.strike = float.Parse(reader[4].ToString());
                        c.full = int.Parse(reader[5].ToString());
                        c.half = int.Parse(reader[6].ToString());



                        b1.Add(c);
                    }



                }
                catch (Exception o)
                {
                    MessageBox.Show(o.Message);
                }
                conn.Close();
                txtgrid.DataSource = b1;
            }
            else if (txt == "Best Average")
            {

                conn.Open();
                List<cskbatsmen> b2 = new List<cskbatsmen>();
                string sql3 = "Select * from cskbatsmen where  average=" + "(Select max(average) from cskbatsmen where average>0)";
                SqlCommand cmd3 = new SqlCommand(sql3, conn);
                SqlDataReader reader = cmd3.ExecuteReader();
                while (reader.Read())
                {
                    cskbatsmen c = new cskbatsmen();
                    c.jersy_no = int.Parse(reader[0].ToString());

                    c.no_of_matches = int.Parse(reader[1].ToString());
                    c.runs = int.Parse(reader[2].ToString());
                    c.b_average = float.Parse(reader[3].ToString());
                    c.strike = float.Parse(reader[4].ToString());
                    c.full = int.Parse(reader[5].ToString());
                    c.half = int.Parse(reader[6].ToString());
                    b2.Add(c);



                }
                conn.Close();
                txtgrid.DataSource = b2;
            }
            else if (txt == "Best StrikeRate")
            {

                conn.Open();
                List<cskbatsmen> b3 = new List<cskbatsmen>();
                string sql4 = "Select * from cskbatsmen where  strike_rate=" + "(Select max(strike_rate) from cskbatsmen  )";
                SqlCommand cmd4 = new SqlCommand(sql4, conn);
                SqlDataReader reader = cmd4.ExecuteReader();
                while (reader.Read())
                {
                    cskbatsmen c = new cskbatsmen();
                    c.jersy_no = int.Parse(reader[0].ToString());
                    
                    c.no_of_matches = int.Parse(reader[1].ToString());
                    c.runs = int.Parse(reader[2].ToString());
                    c.b_average = float.Parse(reader[3].ToString());
                    c.strike= float.Parse(reader[4].ToString());
                    c.full = int.Parse(reader[5].ToString());
                    c.half = int.Parse(reader[6].ToString());

                    b3.Add(c);




                }
                txtgrid.Visible = true;
                conn.Close();
                txtgrid.DataSource = b3;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TeamDetails t = new TeamDetails();
            t.Show();
            this.Hide();
        }
    }
}
