﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{
    public partial class RCBSHOW : Form
    {
        SqlConnection conn;
        public RCBSHOW()
        {
            InitializeComponent();
            conn =new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<rcb_details> pdetails = new List<rcb_details>();
            string sql = "select * from rcb_details";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    rcb_details p = new rcb_details();
                    p.jersy_no = int.Parse(reader[0].ToString());
                    p.player_name = reader[1].ToString();
                    p.role_player = reader[2].ToString();
                    p.nationality = reader[3].ToString();
                    pdetails.Add(p);

                }



            }
            catch (Exception o)

            {
                MessageBox.Show(o.Message);
            }
            txtshow.DataSource = pdetails;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rcbdetails r = new Rcbdetails();
            r.Show();
            this.Hide();
        }
    }
}

