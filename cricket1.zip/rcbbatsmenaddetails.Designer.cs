﻿namespace Cricket_Team_Managment
{
    partial class rcbbatsmenaddetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtstrike = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtwickets = new System.Windows.Forms.NumericUpDown();
            this.txtmatch = new System.Windows.Forms.NumericUpDown();
            this.txtavg = new System.Windows.Forms.TextBox();
            this.txtno = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.txtwickets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmatch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtno)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(377, 361);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 40;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtstrike
            // 
            this.txtstrike.Location = new System.Drawing.Point(418, 259);
            this.txtstrike.Name = "txtstrike";
            this.txtstrike.Size = new System.Drawing.Size(120, 20);
            this.txtstrike.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(267, 266);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Strike Rate";
            // 
            // txtwickets
            // 
            this.txtwickets.Location = new System.Drawing.Point(418, 151);
            this.txtwickets.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.txtwickets.Name = "txtwickets";
            this.txtwickets.Size = new System.Drawing.Size(120, 20);
            this.txtwickets.TabIndex = 37;
            // 
            // txtmatch
            // 
            this.txtmatch.Location = new System.Drawing.Point(418, 110);
            this.txtmatch.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.txtmatch.Name = "txtmatch";
            this.txtmatch.Size = new System.Drawing.Size(120, 20);
            this.txtmatch.TabIndex = 36;
            // 
            // txtavg
            // 
            this.txtavg.Location = new System.Drawing.Point(418, 210);
            this.txtavg.Name = "txtavg";
            this.txtavg.Size = new System.Drawing.Size(120, 20);
            this.txtavg.TabIndex = 35;
            // 
            // txtno
            // 
            this.txtno.Location = new System.Drawing.Point(418, 31);
            this.txtno.Name = "txtno";
            this.txtno.Size = new System.Drawing.Size(120, 20);
            this.txtno.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(266, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 33;
            this.label5.Text = "Batting Average";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(266, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "No of Runs";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(266, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 31;
            this.label3.Text = "No of Matches";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(267, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Jersy No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(266, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 45;
            this.label2.Text = "Player_Name";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(418, 73);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(116, 20);
            this.txtname.TabIndex = 46;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(548, 363);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 47;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // rcbbatsmenaddetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtstrike);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtwickets);
            this.Controls.Add(this.txtmatch);
            this.Controls.Add(this.txtavg);
            this.Controls.Add(this.txtno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "rcbbatsmenaddetails";
            this.Text = "rcbbatsmenaddetails";
            ((System.ComponentModel.ISupportInitialize)(this.txtwickets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmatch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtno)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtstrike;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown txtwickets;
        private System.Windows.Forms.NumericUpDown txtmatch;
        private System.Windows.Forms.TextBox txtavg;
        private System.Windows.Forms.NumericUpDown txtno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Button button2;
    }
}