﻿create database Rcb;
create table rcb_details(  jersy_no  int  primary key NOT NULL ,player_name varchar(50),player_role varchar(50),nationality
varchar(50));
 
 create table rcb_bowlers(jersy_no int  foreign key references rcb_details(jersy_no) , player_name varchar(50)  ,no_of_matches int,no_of_wickets int,
 average float,economy float);

 create table rcb_batsmen(jersy_no int foreign key references rcb_details(jersy_no), player_name varchar(50),no_of_matches int, no_of_runs int,
 batting_average float,strike_rate float);

  