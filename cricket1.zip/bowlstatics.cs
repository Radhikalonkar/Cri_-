﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{
    public partial class bowlstatics : Form
    {
        SqlConnection conn;
        public bowlstatics()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);

        }

        private void button2_Click(object sender, EventArgs e)
        {
             
            string txt = txtsearch.Text.ToString();
            if (txt == "All Details")

            {
                conn.Open();
                List<cskbowler> b = new List<cskbowler>();
                string sql1 = "Select * from cskbowler";
                SqlCommand cmd1= new SqlCommand(sql1, conn);
                SqlDataReader reader = cmd1.ExecuteReader();
                while (reader.Read())
                {
                    cskbowler c = new cskbowler();
                    c.jersy_no = int.Parse(reader[0].ToString());
                    c.player_name = reader[1].ToString();
                    c.no_of_matches = int.Parse(reader[2].ToString());
                    c.wickets = int.Parse(reader[3].ToString());
                    c.average = float.Parse(reader[4].ToString());
                    c.economy = float.Parse(reader[5].ToString());
                    b.Add(c);



                }
                conn.Close();
                txtgrid.DataSource = b;

            }
            else if (txt == "Highest Wicket")
            {

                
                List<cskbowler> b1 = new List<cskbowler>();
                string sql2 = "Select * from cskbowler where no_of_wickets="+"(select max(no_of_wickets) from cskbowler)";
                try { 
                conn.Open();
                SqlCommand cmd2 = new SqlCommand(sql2, conn);
                SqlDataReader reader = cmd2.ExecuteReader();
                    if (reader.Read())
                    {
                        cskbowler c = new cskbowler();
                        c.jersy_no = int.Parse(reader[0].ToString());
                        c.player_name = reader[1].ToString();
                        c.no_of_matches = int.Parse(reader[2].ToString());

                        c.wickets = int.Parse(reader[3].ToString());
                        c.average = float.Parse(reader[4].ToString());
                        c.economy = float.Parse(reader[5].ToString());



                        b1.Add(c);
                    }



                }catch(Exception o)
                {
                    MessageBox.Show(o.Message);
                }
                conn.Close();
                txtgrid.DataSource = b1;
            }
            else if (txt == "Highest Average")
            {

                conn.Open();
                List<cskbowler> b2 = new List<cskbowler>();
                string sql3 = "Select * from cskbowler where  average="+"(Select min(average) from cskbowler where average>0)";
                SqlCommand cmd3 = new SqlCommand(sql3, conn);
                SqlDataReader reader = cmd3.ExecuteReader();
                while (reader.Read())
                {
                    cskbowler c = new cskbowler();
                    c.jersy_no = int.Parse(reader[0].ToString());
                    c.player_name = reader[1].ToString();
                    c.no_of_matches = int.Parse(reader[2].ToString());
                    c.wickets = int.Parse(reader[3].ToString());
                    c.average = float.Parse(reader[4].ToString());
                    c.economy = float.Parse(reader[5].ToString());
                    b2.Add(c);



                }
                conn.Close();
                txtgrid.DataSource = b2;
            }
            else if (txt == "Best Economy")
            {

                conn.Open();
                List<cskbowler> b3 = new List<cskbowler>();
                string sql4 = "Select * from cskbowler where  economy=" + "(Select min(economy) from cskbowler where economy>0)";
                SqlCommand cmd4 = new SqlCommand(sql4, conn);
                SqlDataReader reader = cmd4.ExecuteReader();
                while (reader.Read())
                {
                    cskbowler c = new cskbowler();
                    c.jersy_no = int.Parse(reader[0].ToString());
                    c.player_name = reader[1].ToString();
                    c.no_of_matches = int.Parse(reader[2].ToString());
                    c.wickets = int.Parse(reader[3].ToString());
                    c.average = float.Parse(reader[4].ToString());
                    c.economy = float.Parse(reader[5].ToString());
                    b3.Add(c);
                    



                }
                conn.Close();
                txtgrid.DataSource = b3;
            }
            

        }
            private void button1_Click(object sender, EventArgs e)
            {
                Bowlerdetails b = new Bowlerdetails();
                b.Show();
                this.Hide();
            }

        private void bowlstatics_Load(object sender, EventArgs e)
        {

        }

        private void txtsearch_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtgrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            TeamDetails t = new TeamDetails();
            t.Show();
            this.Hide();
        }
    }

    }
