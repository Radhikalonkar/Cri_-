﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cricket_Team_Managment
{
    class orangecap
    {
        public int jersy_no { get; set; }
        public int runs { get; set; }

        public override string ToString()
        {
            string mydata = "";
            mydata += jersy_no.ToString() + "\n";


            mydata += runs.ToString() + "\n";
            return mydata;
        }
    }
}
