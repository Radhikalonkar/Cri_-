﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Cricket_Team_Managment
{
    public partial class Bowlerdetails : Form
    {
        SqlConnection conn;
        public Bowlerdetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)

        {
            cskbowler b = new cskbowler();
            b.jersy_no = int.Parse(txtno.Value.ToString());
            b.player_name = txtname.Text.ToString();
            b.no_of_matches = int.Parse(txtmatch.Value.ToString());
            b.average = float.Parse(txtavg.Text.ToString());
            b.wickets = int.Parse(txtwickets.Value.ToString());
            b.economy = float.Parse(txteco.Text.ToString());
            string sql2 = String.Format("insert into cskbowler values('{0}','{1}','{2}','{3}','{4}','{5}')", b.jersy_no, b.player_name, b.no_of_matches, b.wickets, b.average, b.economy);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql2, conn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception o)
            {
                MessageBox.Show(o.Message);


            }
            conn.Close();

            

        }
        private void clear()
        {
            txtno.Value = 0;
            txtname.Text = "";
            txtmatch.Value = 0;
            txtwickets.Value = 0;
            txtavg.Text = "";
            txteco.Text = "";

       


        }

        private void button2_Click(object sender, EventArgs e)
        {
            bowlstatics s = new bowlstatics();
            s.Show();
            this.Hide();
        }
    }
}
