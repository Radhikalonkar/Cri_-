﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Managment
{
    public partial class cskplayers : Form
    {
        SqlConnection conn;
        public cskplayers()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb6"].ConnectionString);
        }

        private void cskplayers_Load(object sender, EventArgs e)
        {

        }

        private void txtshow_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        { List<playerdetails> pdetails = new List<playerdetails>();
            string sql = "select * from playerdetails";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    playerdetails p = new playerdetails();
                    p.jersy_no = int.Parse(reader[0].ToString());
                    p.player_name = reader[1].ToString();
                    p.role_player = reader[2].ToString();
                    p.nationality = reader[3].ToString();
                    pdetails.Add(p);
                    
                }



            }catch(Exception o)
            
                {
                MessageBox.Show(o.Message);
                }
            txtshow.DataSource = pdetails;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            TeamDetails t = new TeamDetails();
            t.Show();
            this.Hide();
        }
    }
}
