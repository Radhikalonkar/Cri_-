﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace Cricket_Team_Managment
{
    public partial class rcbbatsmenaddetails : Form
    {
        SqlConnection conn;
        public rcbbatsmenaddetails()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb7"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            rcb_batsmen b = new rcb_batsmen();
            b.jersy_no = int.Parse(txtno.Value.ToString());
            b.player_name = txtname.Text.ToString();

            b.no_of_matches = int.Parse(txtmatch.Value.ToString());
            b.b_average = float.Parse(txtavg.Text.ToString());
            b.runs = int.Parse(txtwickets.Value.ToString());
            b.strike = float.Parse(txtstrike.Text.ToString());
            
            string sql2 = String.Format("insert into rcb_batsmen values('{0}','{1}','{2}','{3}','{4}','{5}')", b.jersy_no,b.player_name, b.no_of_matches, b.runs, b.b_average, b.strike);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql2, conn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception o)
            {
                MessageBox.Show(o.Message);


            }
            conn.Close();
            clear();

        }
        private void clear()
        {
            txtno.Value = 0;
            txtname.Text = "";
            txtmatch.Value = 0;
            txtwickets.Value = 0;
            txtavg.Text = "";
            txtstrike.Text = "";
            



        }

        private void button2_Click(object sender, EventArgs e)
        {
            rcbbatsmendetails r = new rcbbatsmendetails();
            r.Show();
            this.Hide();

        }
    }
    }

